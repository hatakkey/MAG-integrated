db_proxy --jsonfile /etc/sysconfig/configs/db_proxy.json&
