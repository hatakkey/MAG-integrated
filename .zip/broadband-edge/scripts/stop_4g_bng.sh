#!/bin/bash

docker exec -d cups-enodeb2 bin/bash -c "pkill srsenb"
docker exec -d cups-ue3 bin/bash -c "pkill srsue"
