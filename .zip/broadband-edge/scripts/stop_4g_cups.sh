#!/bin/bash

docker exec -d cups-enodeb1 bin/bash -c "pkill srsenb"
docker exec -d cups-ue1 bin/bash -c "pkill srsue"
