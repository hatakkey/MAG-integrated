#!/bin/bash

docker exec -d cups-gnb bin/bash -c "killall nr-gnb"
docker exec -d cups-ue2 bin/bash -c "killall nr-ue"
